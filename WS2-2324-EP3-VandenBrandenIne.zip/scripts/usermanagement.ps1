Add-ADGroupMember -Identity 'Domain Admins' -Members winserver2
Add-ADGroupMember -Identity 'EnterPrise Admins' -Members winserver2
Add-ADGroupMember -Identity 'Schema Admins' -Members winserver2
Add-ADGroupMember -Identity 'Group Policy Creator Owners' -Members winserver2